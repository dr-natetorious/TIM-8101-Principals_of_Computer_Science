========================================================================
    MakeDatasets: creates datasets for the SNAP website
========================================================================

The code demonstrates how to load different kinds of networks in various
network formats and how to compute various statistics of the network, like
diameter, clustering coefficient, size of largest connected component, and
similar.

The code works under Windows with Visual Studio or Cygwin with GCC,
Mac OS X, Linux and other Unix variants with GCC. Make sure that a
C++ compiler is installed on the system. Visual Studio project files
and makefiles are provided. For makefiles, compile the code with
"make all".

/////////////////////////////////////////////////////////////////////////////
Parameters:

/////////////////////////////////////////////////////////////////////////////
Usage:
