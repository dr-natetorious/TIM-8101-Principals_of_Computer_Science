#
#	configuration variables for the example

## Main application file
MAIN = mkdatasets
DEPH = 
DEPCPP = 

