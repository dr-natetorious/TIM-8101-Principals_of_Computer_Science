#
#	configuration variables for the example

## Main application file
MAIN = cliquesmain
DEPH = $(EXSNAPADV)/cliques.h
DEPCPP = $(EXSNAPADV)/cliques.cpp

