========================================================================
    BenchMark : Cascades 
========================================================================
This folder contains algorithms used for final benchmarking for cascade
detection. 
Methods       File
Sort Time     SortTime
Sort Source   SortSource
Baseline      baseline

Time reported is for the detection of a single cascade. All files take 
the staring point of the top cascade as input. 

